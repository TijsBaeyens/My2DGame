package entity;

import javax.swing.plaf.basic.BasicComboBoxUI.KeyHandler;

import main.GamePanel;

public class Player extends Entity{
	GamePanel gp;
	KeyHandler keyH;
	
	public Player(GamePanel gp, KeyHandler keyH) {
		this.gp = gp;
		this.keyH = keyH;
	}
}
