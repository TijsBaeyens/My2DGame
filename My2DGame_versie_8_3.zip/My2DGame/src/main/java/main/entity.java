package main;

public class entity {

}
